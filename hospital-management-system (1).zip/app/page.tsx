"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import PatientForm from "@/components/patient-form"
import DoctorForm from "@/components/doctor-form"
import AppointmentForm from "@/components/appointment-form"
import PatientList from "@/components/patient-list"
import DoctorList from "@/components/doctor-list"
import AppointmentList from "@/components/appointment-list"
import type { Patient, Doctor, Appointment } from "@/lib/types"
import { UserRound, Stethoscope, Calendar } from "lucide-react"

export default function Home() {
  const [patients, setPatients] = useState<Patient[]>([])
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [appointments, setAppointments] = useState<Appointment[]>([])

  const addPatient = (patient: Patient) => {
    setPatients([...patients, patient])
  }

  const addDoctor = (doctor: Doctor) => {
    setDoctors([...doctors, doctor])
  }

  const addAppointment = (appointment: Appointment) => {
    setAppointments([...appointments, appointment])
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-muted p-4 md:p-8">
      <Card className="mx-auto max-w-6xl overflow-hidden shadow-xl border-none">
        <CardHeader className="bg-gradient-to-r from-primary to-secondary text-white p-8">
          <CardTitle className="text-3xl md:text-4xl font-bold">Hospital Management System</CardTitle>
          <CardDescription className="text-white/90 text-lg">
            Manage patients, doctors, and appointments with ease
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <Tabs defaultValue="patients" className="w-full">
            <TabsList className="grid w-full grid-cols-3 p-1 mb-8 bg-muted rounded-xl">
              <TabsTrigger value="patients" className="rounded-lg py-3 data-[state=active]:tab-active">
                <UserRound className="mr-2 h-5 w-5" />
                Patients
              </TabsTrigger>
              <TabsTrigger value="doctors" className="rounded-lg py-3 data-[state=active]:tab-active">
                <Stethoscope className="mr-2 h-5 w-5" />
                Doctors
              </TabsTrigger>
              <TabsTrigger value="appointments" className="rounded-lg py-3 data-[state=active]:tab-active">
                <Calendar className="mr-2 h-5 w-5" />
                Appointments
              </TabsTrigger>
            </TabsList>
            <TabsContent value="patients" className="space-y-6 pt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <PatientForm onAddPatient={addPatient} />
                <PatientList patients={patients} />
              </div>
            </TabsContent>
            <TabsContent value="doctors" className="space-y-6 pt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <DoctorForm onAddDoctor={addDoctor} />
                <DoctorList doctors={doctors} />
              </div>
            </TabsContent>
            <TabsContent value="appointments" className="space-y-6 pt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <AppointmentForm onAddAppointment={addAppointment} patients={patients} doctors={doctors} />
                <AppointmentList appointments={appointments} />
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </main>
  )
}

