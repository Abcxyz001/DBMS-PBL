import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Appointment } from "@/lib/types"
import { CalendarDays, Calendar } from "lucide-react"

interface AppointmentListProps {
  appointments: Appointment[]
}

export default function AppointmentList({ appointments }: AppointmentListProps) {
  return (
    <Card className="card-hover shadow-md">
      <CardHeader className="pb-2 border-b">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <CalendarDays className="mr-2 h-6 w-6 text-accent" />
          Appointment List
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {appointments.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
            <Calendar className="h-16 w-16 text-muted-foreground/40 mb-4" />
            <p className="text-muted-foreground text-lg">No appointments scheduled yet</p>
            <p className="text-muted-foreground/60 text-sm mt-2">Schedule your first appointment using the form</p>
          </div>
        ) : (
          <div className="overflow-auto max-h-[400px]">
            <Table>
              <TableHeader className="bg-muted/50 sticky top-0">
                <TableRow>
                  <TableHead className="font-bold">Date</TableHead>
                  <TableHead className="font-bold">Patient</TableHead>
                  <TableHead className="font-bold">Doctor</TableHead>
                  <TableHead className="font-bold">Specialty</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {appointments.map((appointment, index) => (
                  <TableRow key={index} className={index % 2 === 0 ? "bg-muted/20" : ""}>
                    <TableCell>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent/10 text-accent">
                        {appointment.appointmentDate}
                      </span>
                    </TableCell>
                    <TableCell className="font-medium">{appointment.patient.name}</TableCell>
                    <TableCell>{appointment.doctor.name}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                        {appointment.doctor.specialty}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

