import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Patient } from "@/lib/types"
import { Users, UserRound } from "lucide-react"

interface PatientListProps {
  patients: Patient[]
}

export default function PatientList({ patients }: PatientListProps) {
  return (
    <Card className="card-hover shadow-md">
      <CardHeader className="pb-2 border-b">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <Users className="mr-2 h-6 w-6 text-primary" />
          Patient List
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {patients.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
            <UserRound className="h-16 w-16 text-muted-foreground/40 mb-4" />
            <p className="text-muted-foreground text-lg">No patients added yet</p>
            <p className="text-muted-foreground/60 text-sm mt-2">Add your first patient using the form</p>
          </div>
        ) : (
          <div className="overflow-auto max-h-[400px]">
            <Table>
              <TableHeader className="bg-muted/50 sticky top-0">
                <TableRow>
                  <TableHead className="font-bold">ID</TableHead>
                  <TableHead className="font-bold">Name</TableHead>
                  <TableHead className="font-bold">Age</TableHead>
                  <TableHead className="font-bold">Medical History</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {patients.map((patient, index) => (
                  <TableRow key={patient.patientID} className={index % 2 === 0 ? "bg-muted/20" : ""}>
                    <TableCell className="font-medium">{patient.patientID}</TableCell>
                    <TableCell>{patient.name}</TableCell>
                    <TableCell>{patient.age}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{patient.medicalHistory}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

