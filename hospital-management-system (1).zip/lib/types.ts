export interface Patient {
  patientID: number
  name: string
  age: number
  medicalHistory: string
}

export interface Doctor {
  doctorID: number
  name: string
  specialty: string
}

export interface Appointment {
  patient: Patient
  doctor: Doctor
  appointmentDate: string
}

