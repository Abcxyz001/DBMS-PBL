import AppointmentSection from "@/components/sections/appointment-section"
import { getAppointments } from "@/lib/actions/appointment-actions"
import { getDoctors } from "@/lib/actions/doctor-actions"
import { getPatients } from "@/lib/actions/patient-actions"

export default async function AppointmentsPage() {
  const { appointments = [], error } = await getAppointments()
  const { patients = [] } = await getPatients()
  const { doctors = [] } = await getDoctors()

  return <AppointmentSection appointments={appointments} patients={patients} doctors={doctors} error={error} />
}

