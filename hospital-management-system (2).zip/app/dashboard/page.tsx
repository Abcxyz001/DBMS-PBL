import Dashboard from "@/components/dashboard"
import { getDashboardStats } from "@/lib/actions/dashboard-actions"
import { getDepartments } from "@/lib/actions/department-actions"
import { getDoctors } from "@/lib/actions/doctor-actions"
import { getEmployees } from "@/lib/actions/employee-actions"
import { getPatients } from "@/lib/actions/patient-actions"

export default async function DashboardPage() {
  const { patients = [] } = await getPatients()
  const { doctors = [] } = await getDoctors()
  const { departments = [] } = await getDepartments()
  const { employees = [] } = await getEmployees()
  const dashboardStats = await getDashboardStats()

  return (
    <Dashboard
      patients={patients}
      doctors={doctors}
      departments={departments}
      employees={employees}
      dashboardStats={dashboardStats}
    />
  )
}

