import DepartmentSection from "@/components/sections/department-section"
import { getDepartments } from "@/lib/actions/department-actions"
import { getDoctors } from "@/lib/actions/doctor-actions"

export default async function DepartmentsPage() {
  const { departments = [], error } = await getDepartments()
  const { doctors = [] } = await getDoctors()

  return <DepartmentSection departments={departments} doctors={doctors} error={error} />
}

