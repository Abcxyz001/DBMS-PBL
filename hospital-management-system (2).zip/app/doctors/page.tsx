import DoctorSection from "@/components/sections/doctor-section"
import { getDepartments } from "@/lib/actions/department-actions"
import { getDoctors } from "@/lib/actions/doctor-actions"

export default async function DoctorsPage() {
  const { doctors = [], error } = await getDoctors()
  const { departments = [] } = await getDepartments()

  return <DoctorSection doctors={doctors} departments={departments} error={error} />
}

