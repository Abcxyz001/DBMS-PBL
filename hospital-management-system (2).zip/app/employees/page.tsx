import EmployeeSection from "@/components/sections/employee-section"
import { getDepartments } from "@/lib/actions/department-actions"
import { getEmployees } from "@/lib/actions/employee-actions"

export default async function EmployeesPage() {
  const { employees = [], error } = await getEmployees()
  const { departments = [] } = await getDepartments()

  return <EmployeeSection employees={employees} departments={departments} error={error} />
}

