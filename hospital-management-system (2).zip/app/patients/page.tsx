import PatientSection from "@/components/sections/patient-section"
import { getPatients } from "@/lib/actions/patient-actions"

export default async function PatientsPage() {
  const { patients = [], error } = await getPatients()

  return <PatientSection patients={patients} error={error} />
}

