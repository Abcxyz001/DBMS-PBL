"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import type { Patient, Doctor, Appointment } from "@/lib/types"
import { CalendarPlus, User, Stethoscope, Calendar } from "lucide-react"

interface AppointmentFormProps {
  onAddAppointment: (appointment: Appointment) => void
  patients: Patient[]
  doctors: Doctor[]
}

export default function AppointmentForm({ onAddAppointment, patients, doctors }: AppointmentFormProps) {
  const [patientID, setPatientID] = useState("")
  const [doctorID, setDoctorID] = useState("")
  const [appointmentDate, setAppointmentDate] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const selectedPatient = patients.find((p) => p.patientID === Number.parseInt(patientID))
    const selectedDoctor = doctors.find((d) => d.doctorID === Number.parseInt(doctorID))

    if (selectedPatient && selectedDoctor) {
      const newAppointment: Appointment = {
        patient: selectedPatient,
        doctor: selectedDoctor,
        appointmentDate,
      }

      onAddAppointment(newAppointment)

      // Reset form
      setPatientID("")
      setDoctorID("")
      setAppointmentDate("")
    }
  }

  return (
    <Card className="card-hover border-t-4 border-t-accent shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <CalendarPlus className="mr-2 h-6 w-6 text-accent" />
          Schedule Appointment
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="patientSelect" className="flex items-center text-sm font-medium">
              <User className="mr-2 h-4 w-4 text-muted-foreground" />
              Select Patient
            </Label>
            <Select value={patientID} onValueChange={setPatientID}>
              <SelectTrigger id="patientSelect" className="border-muted focus:border-accent">
                <SelectValue placeholder="Select a patient" />
              </SelectTrigger>
              <SelectContent>
                {patients.map((patient) => (
                  <SelectItem key={patient.patientID} value={patient.patientID.toString()}>
                    {patient.name} (ID: {patient.patientID})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="doctorSelect" className="flex items-center text-sm font-medium">
              <Stethoscope className="mr-2 h-4 w-4 text-muted-foreground" />
              Select Doctor
            </Label>
            <Select value={doctorID} onValueChange={setDoctorID}>
              <SelectTrigger id="doctorSelect" className="border-muted focus:border-accent">
                <SelectValue placeholder="Select a doctor" />
              </SelectTrigger>
              <SelectContent>
                {doctors.map((doctor) => (
                  <SelectItem key={doctor.doctorID} value={doctor.doctorID.toString()}>
                    {doctor.name} ({doctor.specialty})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="appointmentDate" className="flex items-center text-sm font-medium">
              <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
              Appointment Date
            </Label>
            <Input
              id="appointmentDate"
              type="date"
              required
              value={appointmentDate}
              onChange={(e) => setAppointmentDate(e.target.value)}
              className="border-muted focus:border-accent"
            />
          </div>
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-accent to-secondary hover:from-accent/90 hover:to-secondary/90"
            disabled={!patientID || !doctorID || !appointmentDate}
          >
            <CalendarPlus className="mr-2 h-4 w-4" /> Schedule Appointment
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

