"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { Patient, Doctor, Appointment, Department, Employee } from "@/lib/types"
import { UserRound, Stethoscope, Building2, BadgeCheck, TrendingUp, Activity } from "lucide-react"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

interface DashboardProps {
  patients: Patient[]
  doctors: Doctor[]
  appointments: Appointment[]
  departments: Department[]
  employees: Employee[]
}

export default function Dashboard({ patients, doctors, appointments, departments, employees }: DashboardProps) {
  // Sample data for charts
  const patientData = [
    { name: "Jan", count: 65 },
    { name: "Feb", count: 59 },
    { name: "Mar", count: 80 },
    { name: "Apr", count: 81 },
    { name: "May", count: 56 },
    { name: "Jun", count: 55 },
    { name: "Jul", count: 40 },
  ]

  const appointmentData = [
    { name: "Mon", scheduled: 12, completed: 10, cancelled: 2 },
    { name: "Tue", scheduled: 15, completed: 13, cancelled: 1 },
    { name: "Wed", scheduled: 18, completed: 15, cancelled: 3 },
    { name: "Thu", scheduled: 14, completed: 12, cancelled: 2 },
    { name: "Fri", scheduled: 20, completed: 18, cancelled: 2 },
    { name: "Sat", scheduled: 10, completed: 8, cancelled: 1 },
    { name: "Sun", scheduled: 5, completed: 4, cancelled: 1 },
  ]

  const departmentData = [
    { name: "Cardiology", value: 25 },
    { name: "Neurology", value: 18 },
    { name: "Pediatrics", value: 22 },
    { name: "Orthopedics", value: 15 },
    { name: "Oncology", value: 20 },
  ]

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8"]

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
            <UserRound className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{patients.length || 65}</div>
            <p className="text-xs text-muted-foreground flex items-center mt-1">
              <TrendingUp className="mr-1 h-3 w-3 text-accent" />
              <span className="text-accent">+12%</span> from last month
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Doctors</CardTitle>
            <Stethoscope className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{doctors.length || 24}</div>
            <p className="text-xs text-muted-foreground flex items-center mt-1">
              <TrendingUp className="mr-1 h-3 w-3 text-accent" />
              <span className="text-accent">+5%</span> from last month
            </p>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Departments</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{departments.length || 8}</div>
            <p className="text-xs text-muted-foreground mt-1">Across multiple specialties</p>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Employees</CardTitle>
            <BadgeCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{employees.length || 120}</div>
            <p className="text-xs text-muted-foreground flex items-center mt-1">
              <Activity className="mr-1 h-3 w-3 text-accent" />
              <span className="text-accent">98%</span> active
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Patient Registration</CardTitle>
            <CardDescription>Monthly patient registration trend</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={patientData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="count" stroke="#3b82f6" activeDot={{ r: 8 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Appointments</CardTitle>
            <CardDescription>Weekly appointment statistics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={appointmentData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="scheduled" fill="#3b82f6" />
                  <Bar dataKey="completed" fill="#10b981" />
                  <Bar dataKey="cancelled" fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Distribution and Recent Appointments */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Department Distribution</CardTitle>
            <CardDescription>Patient distribution by department</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={departmentData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {departmentData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Recent Appointments</CardTitle>
            <CardDescription>Latest scheduled appointments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {appointments.length > 0
                ? appointments.slice(0, 5).map((appointment, i) => (
                    <div key={i} className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt="Patient" />
                        <AvatarFallback>{appointment.patient.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium">{appointment.patient.name}</p>
                        <p className="text-xs text-muted-foreground">
                          Dr. {appointment.doctor.name} • {appointment.appointmentDate}
                        </p>
                      </div>
                      <Badge
                        variant={
                          appointment.status === "scheduled"
                            ? "outline"
                            : appointment.status === "completed"
                              ? "secondary"
                              : "destructive"
                        }
                      >
                        {appointment.status}
                      </Badge>
                    </div>
                  ))
                : Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt="Patient" />
                        <AvatarFallback>P</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium">Patient {i + 1}</p>
                        <p className="text-xs text-muted-foreground">Dr. Smith • {new Date().toLocaleDateString()}</p>
                      </div>
                      <Badge variant={i % 3 === 0 ? "outline" : i % 3 === 1 ? "secondary" : "destructive"}>
                        {i % 3 === 0 ? "scheduled" : i % 3 === 1 ? "completed" : "cancelled"}
                      </Badge>
                    </div>
                  ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

