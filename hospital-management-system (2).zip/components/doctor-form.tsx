"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import type { Doctor } from "@/lib/types"
import { UserPlus, Stethoscope, User, Award } from "lucide-react"

interface DoctorFormProps {
  onAddDoctor: (doctor: Doctor) => void
}

export default function DoctorForm({ onAddDoctor }: DoctorFormProps) {
  const [doctorID, setDoctorID] = useState("")
  const [name, setName] = useState("")
  const [specialty, setSpecialty] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newDoctor: Doctor = {
      doctorID: Number.parseInt(doctorID),
      name,
      specialty,
    }

    onAddDoctor(newDoctor)

    // Reset form
    setDoctorID("")
    setName("")
    setSpecialty("")
  }

  return (
    <Card className="card-hover border-t-4 border-t-secondary shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <Stethoscope className="mr-2 h-6 w-6 text-secondary" />
          Add New Doctor
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="doctorID" className="flex items-center text-sm font-medium">
              <User className="mr-2 h-4 w-4 text-muted-foreground" />
              Doctor ID
            </Label>
            <Input
              id="doctorID"
              type="number"
              required
              value={doctorID}
              onChange={(e) => setDoctorID(e.target.value)}
              className="border-muted focus:border-secondary"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="name" className="flex items-center text-sm font-medium">
              <User className="mr-2 h-4 w-4 text-muted-foreground" />
              Name
            </Label>
            <Input
              id="name"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border-muted focus:border-secondary"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="specialty" className="flex items-center text-sm font-medium">
              <Award className="mr-2 h-4 w-4 text-muted-foreground" />
              Specialty
            </Label>
            <Input
              id="specialty"
              required
              value={specialty}
              onChange={(e) => setSpecialty(e.target.value)}
              className="border-muted focus:border-secondary"
            />
          </div>
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-secondary to-primary hover:from-secondary/90 hover:to-primary/90"
          >
            <UserPlus className="mr-2 h-4 w-4" /> Add Doctor
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

