import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Doctor } from "@/lib/types"
import { Users, Stethoscope } from "lucide-react"

interface DoctorListProps {
  doctors: Doctor[]
}

export default function DoctorList({ doctors }: DoctorListProps) {
  return (
    <Card className="card-hover shadow-md">
      <CardHeader className="pb-2 border-b">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <Users className="mr-2 h-6 w-6 text-secondary" />
          Doctor List
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {doctors.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
            <Stethoscope className="h-16 w-16 text-muted-foreground/40 mb-4" />
            <p className="text-muted-foreground text-lg">No doctors added yet</p>
            <p className="text-muted-foreground/60 text-sm mt-2">Add your first doctor using the form</p>
          </div>
        ) : (
          <div className="overflow-auto max-h-[400px]">
            <Table>
              <TableHeader className="bg-muted/50 sticky top-0">
                <TableRow>
                  <TableHead className="font-bold">ID</TableHead>
                  <TableHead className="font-bold">Name</TableHead>
                  <TableHead className="font-bold">Specialty</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {doctors.map((doctor, index) => (
                  <TableRow key={doctor.doctorID} className={index % 2 === 0 ? "bg-muted/20" : ""}>
                    <TableCell className="font-medium">{doctor.doctorID}</TableCell>
                    <TableCell>{doctor.name}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                        {doctor.specialty}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

