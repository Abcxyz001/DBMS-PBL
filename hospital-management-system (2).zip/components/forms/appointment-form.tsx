"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { Patient, Doctor, Appointment } from "@/lib/types"
import { CalendarPlus } from "lucide-react"

interface AppointmentFormProps {
  onAddAppointment: (appointment: Appointment) => void
  patients: Patient[]
  doctors: Doctor[]
}

export default function AppointmentForm({ onAddAppointment, patients, doctors }: AppointmentFormProps) {
  const [appointmentID, setAppointmentID] = useState("")
  const [patientID, setPatientID] = useState("")
  const [doctorID, setDoctorID] = useState("")
  const [appointmentDate, setAppointmentDate] = useState("")
  const [appointmentTime, setAppointmentTime] = useState("")
  const [status, setStatus] = useState<"scheduled" | "completed" | "cancelled">("scheduled")
  const [purpose, setPurpose] = useState("")
  const [notes, setNotes] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const selectedPatient = patients.find((p) => p.patientID === Number.parseInt(patientID))
    const selectedDoctor = doctors.find((d) => d.doctorID === Number.parseInt(doctorID))

    if (selectedPatient && selectedDoctor) {
      const newAppointment: Appointment = {
        appointmentID: Number.parseInt(appointmentID),
        patient: selectedPatient,
        doctor: selectedDoctor,
        appointmentDate,
        appointmentTime,
        status,
        purpose,
        notes,
      }

      onAddAppointment(newAppointment)

      // Reset form
      setAppointmentID("")
      setPatientID("")
      setDoctorID("")
      setAppointmentDate("")
      setAppointmentTime("")
      setStatus("scheduled")
      setPurpose("")
      setNotes("")
    }
  }

  return (
    <Card className="card-hover border-t-4 border-t-accent shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <CalendarPlus className="mr-2 h-6 w-6 text-accent" />
          Schedule Appointment
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="appointmentID">Appointment ID</Label>
              <Input
                id="appointmentID"
                type="number"
                required
                value={appointmentID}
                onChange={(e) => setAppointmentID(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="patientSelect">Select Patient</Label>
              <Select value={patientID} onValueChange={setPatientID} required>
                <SelectTrigger id="patientSelect">
                  <SelectValue placeholder="Select a patient" />
                </SelectTrigger>
                <SelectContent>
                  {patients.length > 0 ? (
                    patients.map((patient) => (
                      <SelectItem key={patient.patientID} value={patient.patientID.toString()}>
                        {patient.name} (ID: {patient.patientID})
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="1">John Doe (ID: 1)</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="doctorSelect">Select Doctor</Label>
              <Select value={doctorID} onValueChange={setDoctorID} required>
                <SelectTrigger id="doctorSelect">
                  <SelectValue placeholder="Select a doctor" />
                </SelectTrigger>
                <SelectContent>
                  {doctors.length > 0 ? (
                    doctors.map((doctor) => (
                      <SelectItem key={doctor.doctorID} value={doctor.doctorID.toString()}>
                        Dr. {doctor.name} ({doctor.specialty})
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="1">Dr. Smith (Cardiology)</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="appointmentDate">Appointment Date</Label>
              <Input
                id="appointmentDate"
                type="date"
                required
                value={appointmentDate}
                onChange={(e) => setAppointmentDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="appointmentTime">Appointment Time</Label>
              <Input
                id="appointmentTime"
                type="time"
                required
                value={appointmentTime}
                onChange={(e) => setAppointmentTime(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={status}
                onValueChange={(value) => setStatus(value as "scheduled" | "completed" | "cancelled")}
              >
                <SelectTrigger id="status">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="purpose">Purpose</Label>
            <Input
              id="purpose"
              placeholder="Reason for appointment"
              required
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Additional notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-accent to-secondary hover:from-accent/90 hover:to-secondary/90"
            disabled={!patientID || !doctorID || !appointmentDate || !appointmentTime}
          >
            <CalendarPlus className="mr-2 h-4 w-4" /> Schedule Appointment
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

