"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import type { Department } from "@/lib/types"
import { Building2 } from "lucide-react"

interface DepartmentFormProps {
  onAddDepartment: (department: Department) => void
}

export default function DepartmentForm({ onAddDepartment }: DepartmentFormProps) {
  const [departmentID, setDepartmentID] = useState("")
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [headDoctor, setHeadDoctor] = useState("")
  const [location, setLocation] = useState("")
  const [contactExt, setContactExt] = useState("")
  const [establishedDate, setEstablishedDate] = useState(new Date().toISOString().split("T")[0])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newDepartment: Department = {
      departmentID: Number.parseInt(departmentID),
      name,
      description,
      headDoctor,
      location,
      contactExt,
      establishedDate,
    }

    onAddDepartment(newDepartment)

    // Reset form
    setDepartmentID("")
    setName("")
    setDescription("")
    setHeadDoctor("")
    setLocation("")
    setContactExt("")
    setEstablishedDate(new Date().toISOString().split("T")[0])
  }

  return (
    <Card className="card-hover border-t-4 border-t-primary shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <Building2 className="mr-2 h-6 w-6 text-primary" />
          Add New Department
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="departmentID">Department ID</Label>
              <Input
                id="departmentID"
                type="number"
                required
                value={departmentID}
                onChange={(e) => setDepartmentID(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Department Name</Label>
              <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="headDoctor">Head Doctor</Label>
              <Input id="headDoctor" required value={headDoctor} onChange={(e) => setHeadDoctor(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                placeholder="Building, Floor, etc."
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contactExt">Contact Extension</Label>
              <Input
                id="contactExt"
                placeholder="e.g. Ext. 1234"
                required
                value={contactExt}
                onChange={(e) => setContactExt(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="establishedDate">Established Date</Label>
              <Input
                id="establishedDate"
                type="date"
                required
                value={establishedDate}
                onChange={(e) => setEstablishedDate(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="min-h-[100px]"
            />
          </div>

          <Button type="submit" className="w-full btn-gradient">
            <Building2 className="mr-2 h-4 w-4" /> Add Department
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

