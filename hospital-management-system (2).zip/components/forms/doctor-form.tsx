"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import type { Doctor, Department } from "@/lib/types"
import { UserPlus } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface DoctorFormProps {
  onAddDoctor: (doctor: Doctor) => void
  departments: Department[]
}

export default function DoctorForm({ onAddDoctor, departments }: DoctorFormProps) {
  const [doctorID, setDoctorID] = useState("")
  const [name, setName] = useState("")
  const [specialty, setSpecialty] = useState("")
  const [departmentID, setDepartmentID] = useState("")
  const [qualification, setQualification] = useState("")
  const [experience, setExperience] = useState("")
  const [contact, setContact] = useState("")
  const [email, setEmail] = useState("")
  const [schedule, setSchedule] = useState("")
  const [joinDate, setJoinDate] = useState(new Date().toISOString().split("T")[0])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newDoctor: Doctor = {
      doctorID: Number.parseInt(doctorID),
      name,
      specialty,
      departmentID: Number.parseInt(departmentID),
      qualification,
      experience: Number.parseInt(experience),
      contact,
      email,
      schedule,
      joinDate,
    }

    onAddDoctor(newDoctor)

    // Reset form
    setDoctorID("")
    setName("")
    setSpecialty("")
    setDepartmentID("")
    setQualification("")
    setExperience("")
    setContact("")
    setEmail("")
    setSchedule("")
    setJoinDate(new Date().toISOString().split("T")[0])
  }

  return (
    <Card className="card-hover border-t-4 border-t-secondary shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <UserPlus className="mr-2 h-6 w-6 text-secondary" />
          Add New Doctor
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="doctorID">Doctor ID</Label>
              <Input
                id="doctorID"
                type="number"
                required
                value={doctorID}
                onChange={(e) => setDoctorID(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="specialty">Specialty</Label>
              <Input id="specialty" required value={specialty} onChange={(e) => setSpecialty(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="departmentID">Department</Label>
              <Select value={departmentID} onValueChange={setDepartmentID} required>
                <SelectTrigger id="departmentID">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.length > 0 ? (
                    departments.map((dept) => (
                      <SelectItem key={dept.departmentID} value={dept.departmentID.toString()}>
                        {dept.name}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="1">Cardiology</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="qualification">Qualification</Label>
              <Input
                id="qualification"
                required
                value={qualification}
                onChange={(e) => setQualification(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="experience">Experience (years)</Label>
              <Input
                id="experience"
                type="number"
                required
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact">Contact Number</Label>
              <Input id="contact" required value={contact} onChange={(e) => setContact(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="schedule">Schedule</Label>
              <Input
                id="schedule"
                placeholder="e.g. Mon-Fri, 9AM-5PM"
                required
                value={schedule}
                onChange={(e) => setSchedule(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="joinDate">Join Date</Label>
              <Input
                id="joinDate"
                type="date"
                required
                value={joinDate}
                onChange={(e) => setJoinDate(e.target.value)}
              />
            </div>
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-secondary to-primary hover:from-secondary/90 hover:to-primary/90"
          >
            <UserPlus className="mr-2 h-4 w-4" /> Add Doctor
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

