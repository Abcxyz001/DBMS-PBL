"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import type { Employee, Department } from "@/lib/types"
import { BadgeCheck } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface EmployeeFormProps {
  onAddEmployee: (employee: Employee) => void
  departments: Department[]
}

export default function EmployeeForm({ onAddEmployee, departments }: EmployeeFormProps) {
  const [employeeID, setEmployeeID] = useState("")
  const [name, setName] = useState("")
  const [role, setRole] = useState("")
  const [departmentID, setDepartmentID] = useState("")
  const [contact, setContact] = useState("")
  const [email, setEmail] = useState("")
  const [address, setAddress] = useState("")
  const [joinDate, setJoinDate] = useState(new Date().toISOString().split("T")[0])
  const [salary, setSalary] = useState("")
  const [status, setStatus] = useState<"active" | "on leave" | "terminated">("active")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newEmployee: Employee = {
      employeeID: Number.parseInt(employeeID),
      name,
      role,
      departmentID: Number.parseInt(departmentID),
      contact,
      email,
      address,
      joinDate,
      salary: Number.parseFloat(salary),
      status,
    }

    onAddEmployee(newEmployee)

    // Reset form
    setEmployeeID("")
    setName("")
    setRole("")
    setDepartmentID("")
    setContact("")
    setEmail("")
    setAddress("")
    setJoinDate(new Date().toISOString().split("T")[0])
    setSalary("")
    setStatus("active")
  }

  return (
    <Card className="card-hover border-t-4 border-t-secondary shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <BadgeCheck className="mr-2 h-6 w-6 text-secondary" />
          Add New Employee
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="employeeID">Employee ID</Label>
              <Input
                id="employeeID"
                type="number"
                required
                value={employeeID}
                onChange={(e) => setEmployeeID(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Role</Label>
              <Select value={role} onValueChange={setRole} required>
                <SelectTrigger id="role">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Nurse">Nurse</SelectItem>
                  <SelectItem value="Receptionist">Receptionist</SelectItem>
                  <SelectItem value="Lab Technician">Lab Technician</SelectItem>
                  <SelectItem value="Pharmacist">Pharmacist</SelectItem>
                  <SelectItem value="Administrator">Administrator</SelectItem>
                  <SelectItem value="IT Staff">IT Staff</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Security">Security</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="departmentID">Department</Label>
              <Select value={departmentID} onValueChange={setDepartmentID} required>
                <SelectTrigger id="departmentID">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.length > 0 ? (
                    departments.map((dept) => (
                      <SelectItem key={dept.departmentID} value={dept.departmentID.toString()}>
                        {dept.name}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="1">Administration</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact">Contact Number</Label>
              <Input id="contact" required value={contact} onChange={(e) => setContact(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="joinDate">Join Date</Label>
              <Input
                id="joinDate"
                type="date"
                required
                value={joinDate}
                onChange={(e) => setJoinDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="salary">Salary</Label>
              <Input
                id="salary"
                type="number"
                step="0.01"
                required
                value={salary}
                onChange={(e) => setSalary(e.target.value)}
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={status}
                onValueChange={(value) => setStatus(value as "active" | "on leave" | "terminated")}
                required
              >
                <SelectTrigger id="status">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="on leave">On Leave</SelectItem>
                  <SelectItem value="terminated">Terminated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Textarea id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-secondary to-primary hover:from-secondary/90 hover:to-primary/90"
          >
            <BadgeCheck className="mr-2 h-4 w-4" /> Add Employee
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

