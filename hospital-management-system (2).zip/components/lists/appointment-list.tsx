import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Appointment } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, Calendar, FileEdit, Trash2, FileText, CheckCircle, XCircle } from "lucide-react"

interface AppointmentListProps {
  appointments: Appointment[]
}

export default function AppointmentList({ appointments }: AppointmentListProps) {
  const getStatusBadge = (status: "scheduled" | "completed" | "cancelled") => {
    switch (status) {
      case "scheduled":
        return (
          <Badge variant="outline" className="bg-blue-500/10 text-blue-500">
            Scheduled
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="bg-green-500/10 text-green-500">
            Completed
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-500/10 text-red-500">
            Cancelled
          </Badge>
        )
    }
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader className="bg-muted/50">
          <TableRow>
            <TableHead className="w-[80px]">ID</TableHead>
            <TableHead>Patient</TableHead>
            <TableHead>Doctor</TableHead>
            <TableHead>Date & Time</TableHead>
            <TableHead>Purpose</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {appointments.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                <div className="flex flex-col items-center justify-center">
                  <Calendar className="h-10 w-10 text-muted-foreground/40 mb-2" />
                  <p className="text-muted-foreground text-lg">No appointments found</p>
                  <p className="text-muted-foreground/60 text-sm mt-1">Schedule a new appointment to get started</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            appointments.map((appointment, index) => (
              <TableRow key={appointment.appointmentID} className={index % 2 === 0 ? "bg-muted/20" : ""}>
                <TableCell className="font-medium">{appointment.appointmentID}</TableCell>
                <TableCell>{appointment.patient.name}</TableCell>
                <TableCell>Dr. {appointment.doctor.name}</TableCell>
                <TableCell>
                  <div>
                    <p>{appointment.appointmentDate}</p>
                    <p className="text-xs text-muted-foreground">{appointment.appointmentTime}</p>
                  </div>
                </TableCell>
                <TableCell className="max-w-[200px] truncate">{appointment.purpose}</TableCell>
                <TableCell>{getStatusBadge(appointment.status)}</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer">
                        <FileText className="mr-2 h-4 w-4" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem className="cursor-pointer">
                        <FileEdit className="mr-2 h-4 w-4" />
                        Edit Appointment
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer">
                        <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                        Mark as Completed
                      </DropdownMenuItem>
                      <DropdownMenuItem className="cursor-pointer">
                        <XCircle className="mr-2 h-4 w-4 text-red-500" />
                        Cancel Appointment
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete Appointment
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}

