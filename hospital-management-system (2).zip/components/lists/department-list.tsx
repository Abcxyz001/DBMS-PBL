import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Department, Doctor } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, Building2, FileEdit, Trash2, FileText, Users } from "lucide-react"

interface DepartmentListProps {
  departments: Department[]
  doctors: Doctor[]
}

export default function DepartmentList({ departments, doctors }: DepartmentListProps) {
  const getDoctorCount = (departmentID: number) => {
    return doctors.filter((d) => d.departmentID === departmentID).length
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader className="bg-muted/50">
          <TableRow>
            <TableHead className="w-[80px]">ID</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Head Doctor</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Contact</TableHead>
            <TableHead>Staff Count</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {departments.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                <div className="flex flex-col items-center justify-center">
                  <Building2 className="h-10 w-10 text-muted-foreground/40 mb-2" />
                  <p className="text-muted-foreground text-lg">No departments found</p>
                  <p className="text-muted-foreground/60 text-sm mt-1">Add a new department to get started</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            departments.map((department, index) => (
              <TableRow key={department.departmentID} className={index % 2 === 0 ? "bg-muted/20" : ""}>
                <TableCell className="font-medium">{department.departmentID}</TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{department.name}</p>
                    <p className="text-xs text-muted-foreground truncate max-w-[200px]">{department.description}</p>
                  </div>
                </TableCell>
                <TableCell>{department.headDoctor}</TableCell>
                <TableCell>{department.location}</TableCell>
                <TableCell>{department.contactExt}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-primary/10">
                    <Users className="h-3 w-3 mr-1" />
                    {getDoctorCount(department.departmentID) || 0}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer">
                        <FileText className="mr-2 h-4 w-4" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem className="cursor-pointer">
                        <FileEdit className="mr-2 h-4 w-4" />
                        Edit Department
                      </DropdownMenuItem>
                      <DropdownMenuItem className="cursor-pointer">
                        <Users className="mr-2 h-4 w-4" />
                        View Staff
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete Department
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}

