import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Doctor, Department } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, Stethoscope, FileEdit, Trash2, FileText } from "lucide-react"

interface DoctorListProps {
  doctors: Doctor[]
  departments: Department[]
}

export default function DoctorList({ doctors, departments }: DoctorListProps) {
  const getDepartmentName = (departmentID: number) => {
    const department = departments.find((d) => d.departmentID === departmentID)
    return department ? department.name : "Unknown Department"
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader className="bg-muted/50">
          <TableRow>
            <TableHead className="w-[80px]">ID</TableHead>
            <TableHead>Doctor</TableHead>
            <TableHead>Specialty</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Contact</TableHead>
            <TableHead>Experience</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {doctors.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                <div className="flex flex-col items-center justify-center">
                  <Stethoscope className="h-10 w-10 text-muted-foreground/40 mb-2" />
                  <p className="text-muted-foreground text-lg">No doctors found</p>
                  <p className="text-muted-foreground/60 text-sm mt-1">Add a new doctor to get started</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            doctors.map((doctor, index) => (
              <TableRow key={doctor.doctorID} className={index % 2 === 0 ? "bg-muted/20" : ""}>
                <TableCell className="font-medium">{doctor.doctorID}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={doctor.name} />
                      <AvatarFallback>{doctor.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">Dr. {doctor.name}</p>
                      <p className="text-xs text-muted-foreground">{doctor.email}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-secondary/10">
                    {doctor.specialty}
                  </Badge>
                </TableCell>
                <TableCell>{getDepartmentName(doctor.departmentID)}</TableCell>
                <TableCell>{doctor.contact}</TableCell>
                <TableCell>{doctor.experience} years</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer">
                        <FileText className="mr-2 h-4 w-4" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem className="cursor-pointer">
                        <FileEdit className="mr-2 h-4 w-4" />
                        Edit Doctor
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete Doctor
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}

