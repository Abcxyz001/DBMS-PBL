import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Employee, Department } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, BadgeCheck, FileEdit, Trash2, FileText } from "lucide-react"

interface EmployeeListProps {
  employees: Employee[]
  departments: Department[]
}

export default function EmployeeList({ employees, departments }: EmployeeListProps) {
  const getDepartmentName = (departmentID: number) => {
    const department = departments.find((d) => d.departmentID === departmentID)
    return department ? department.name : "Unknown Department"
  }

  const getStatusBadge = (status: "active" | "on leave" | "terminated") => {
    switch (status) {
      case "active":
        return (
          <Badge variant="outline" className="bg-green-500/10 text-green-500">
            Active
          </Badge>
        )
      case "on leave":
        return (
          <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500">
            On Leave
          </Badge>
        )
      case "terminated":
        return (
          <Badge variant="outline" className="bg-red-500/10 text-red-500">
            Terminated
          </Badge>
        )
    }
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader className="bg-muted/50">
          <TableRow>
            <TableHead className="w-[80px]">ID</TableHead>
            <TableHead>Employee</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Contact</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {employees.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                <div className="flex flex-col items-center justify-center">
                  <BadgeCheck className="h-10 w-10 text-muted-foreground/40 mb-2" />
                  <p className="text-muted-foreground text-lg">No employees found</p>
                  <p className="text-muted-foreground/60 text-sm mt-1">Add a new employee to get started</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            employees.map((employee, index) => (
              <TableRow key={employee.employeeID} className={index % 2 === 0 ? "bg-muted/20" : ""}>
                <TableCell className="font-medium">{employee.employeeID}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={employee.name} />
                      <AvatarFallback>{employee.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{employee.name}</p>
                      <p className="text-xs text-muted-foreground">{employee.email}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-secondary/10">
                    {employee.role}
                  </Badge>
                </TableCell>
                <TableCell>{getDepartmentName(employee.departmentID)}</TableCell>
                <TableCell>{employee.contact}</TableCell>
                <TableCell>{getStatusBadge(employee.status)}</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer">
                        <FileText className="mr-2 h-4 w-4" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem className="cursor-pointer">
                        <FileEdit className="mr-2 h-4 w-4" />
                        Edit Employee
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="cursor-pointer text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete Employee
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}

