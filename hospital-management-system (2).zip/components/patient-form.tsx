"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import type { Patient } from "@/lib/types"
import { UserPlus, User, Calendar, FileText } from "lucide-react"

interface PatientFormProps {
  onAddPatient: (patient: Patient) => void
}

export default function PatientForm({ onAddPatient }: PatientFormProps) {
  const [patientID, setPatientID] = useState("")
  const [name, setName] = useState("")
  const [age, setAge] = useState("")
  const [medicalHistory, setMedicalHistory] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newPatient: Patient = {
      patientID: Number.parseInt(patientID),
      name,
      age: Number.parseInt(age),
      medicalHistory,
    }

    onAddPatient(newPatient)

    // Reset form
    setPatientID("")
    setName("")
    setAge("")
    setMedicalHistory("")
  }

  return (
    <Card className="card-hover border-t-4 border-t-primary shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-2xl gradient-heading">
          <UserPlus className="mr-2 h-6 w-6 text-primary" />
          Add New Patient
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="patientID" className="flex items-center text-sm font-medium">
              <User className="mr-2 h-4 w-4 text-muted-foreground" />
              Patient ID
            </Label>
            <Input
              id="patientID"
              type="number"
              required
              value={patientID}
              onChange={(e) => setPatientID(e.target.value)}
              className="border-muted focus:border-primary"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="name" className="flex items-center text-sm font-medium">
              <User className="mr-2 h-4 w-4 text-muted-foreground" />
              Name
            </Label>
            <Input
              id="name"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border-muted focus:border-primary"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="age" className="flex items-center text-sm font-medium">
              <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
              Age
            </Label>
            <Input
              id="age"
              type="number"
              required
              value={age}
              onChange={(e) => setAge(e.target.value)}
              className="border-muted focus:border-primary"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="medicalHistory" className="flex items-center text-sm font-medium">
              <FileText className="mr-2 h-4 w-4 text-muted-foreground" />
              Medical History
            </Label>
            <Textarea
              id="medicalHistory"
              required
              value={medicalHistory}
              onChange={(e) => setMedicalHistory(e.target.value)}
              className="border-muted focus:border-primary min-h-[100px]"
            />
          </div>
          <Button type="submit" className="w-full btn-gradient">
            <UserPlus className="mr-2 h-4 w-4" /> Add Patient
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

