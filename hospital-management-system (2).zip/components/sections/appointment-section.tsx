"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Patient, Doctor, Appointment } from "@/lib/types"
import AppointmentForm from "@/components/forms/appointment-form"
import AppointmentList from "@/components/lists/appointment-list"
import { CalendarPlus, FileText, ListFilter, Search, Users } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AppointmentSectionProps {
  appointments: Appointment[]
  onAddAppointment: (appointment: Appointment) => void
  patients: Patient[]
  doctors: Doctor[]
}

export default function AppointmentSection({
  appointments,
  onAddAppointment,
  patients,
  doctors,
}: AppointmentSectionProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("")

  const filteredAppointments = appointments.filter((appointment) => {
    const matchesSearch =
      appointment.patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      appointment.doctor.name.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = filterStatus ? appointment.status === filterStatus : true

    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-3xl font-bold tracking-tight">Appointment Management</h2>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <FileText className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <CalendarPlus className="mr-2 h-4 w-4" />
            Schedule Appointment
          </Button>
        </div>
      </div>

      <Tabs defaultValue="list" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="list">
            <Users className="mr-2 h-4 w-4" />
            Appointment List
          </TabsTrigger>
          <TabsTrigger value="add">
            <CalendarPlus className="mr-2 h-4 w-4" />
            Schedule Appointment
          </TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Appointments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search appointments..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <ListFilter className="h-4 w-4 text-muted-foreground" />
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="scheduled">Scheduled</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <AppointmentList appointments={filteredAppointments} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="add">
          <AppointmentForm onAddAppointment={onAddAppointment} patients={patients} doctors={doctors} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

