"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Department, Doctor } from "@/lib/types"
import DepartmentForm from "@/components/forms/department-form"
import DepartmentList from "@/components/lists/department-list"
import { Building2, FileText, Search, Users } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface DepartmentSectionProps {
  departments: Department[]
  onAddDepartment: (department: Department) => void
  doctors: Doctor[]
}

export default function DepartmentSection({ departments, onAddDepartment, doctors }: DepartmentSectionProps) {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredDepartments = departments.filter(
    (department) =>
      department.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      department.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-3xl font-bold tracking-tight">Department Management</h2>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <FileText className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <Building2 className="mr-2 h-4 w-4" />
            Add Department
          </Button>
        </div>
      </div>

      <Tabs defaultValue="list" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="list">
            <Users className="mr-2 h-4 w-4" />
            Department List
          </TabsTrigger>
          <TabsTrigger value="add">
            <Building2 className="mr-2 h-4 w-4" />
            Add Department
          </TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Departments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search departments..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              <DepartmentList departments={filteredDepartments} doctors={doctors} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="add">
          <DepartmentForm onAddDepartment={onAddDepartment} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

