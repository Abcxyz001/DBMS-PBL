"use server"

import { prisma } from "@/lib/db"
import { revalidatePath } from "next/cache"
import { z } from "zod"

// Validation schema
const AppointmentSchema = z.object({
  appointmentID: z.coerce.number().positive(),
  patientID: z.coerce.number().positive(),
  doctorID: z.coerce.number().positive(),
  appointmentDate: z.string().transform((str) => new Date(str)),
  appointmentTime: z.string(),
  status: z.enum(["scheduled", "completed", "cancelled"]),
  purpose: z.string().min(2),
  notes: z.string().optional(),
})

export type AppointmentFormData = z.infer<typeof AppointmentSchema>

export async function getAppointments() {
  try {
    const appointments = await prisma.appointment.findMany({
      include: {
        patient: true,
        doctor: {
          include: {
            department: true,
          },
        },
      },
      orderBy: { appointmentDate: "desc" },
    })
    return { appointments }
  } catch (error) {
    console.error("Failed to fetch appointments:", error)
    return { error: "Failed to fetch appointments" }
  }
}

export async function getAppointmentById(id: number) {
  try {
    const appointment = await prisma.appointment.findUnique({
      where: { appointmentID: id },
      include: {
        patient: true,
        doctor: {
          include: {
            department: true,
          },
        },
      },
    })
    return { appointment }
  } catch (error) {
    console.error(`Failed to fetch appointment with ID ${id}:`, error)
    return { error: `Failed to fetch appointment with ID ${id}` }
  }
}

export async function createAppointment(data: AppointmentFormData) {
  try {
    // Validate data
    const validatedData = AppointmentSchema.parse(data)

    // Check if appointment ID already exists
    const existingAppointment = await prisma.appointment.findUnique({
      where: { appointmentID: validatedData.appointmentID },
    })

    if (existingAppointment) {
      return { error: "An appointment with this ID already exists" }
    }

    // Check if patient exists
    const patient = await prisma.patient.findUnique({
      where: { patientID: validatedData.patientID },
    })

    if (!patient) {
      return { error: "The selected patient does not exist" }
    }

    // Check if doctor exists
    const doctor = await prisma.doctor.findUnique({
      where: { doctorID: validatedData.doctorID },
    })

    if (!doctor) {
      return { error: "The selected doctor does not exist" }
    }

    // Create appointment
    const appointment = await prisma.appointment.create({
      data: validatedData,
    })

    revalidatePath("/appointments")
    return { appointment }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error("Failed to create appointment:", error)
    return { error: "Failed to create appointment" }
  }
}

export async function updateAppointment(id: number, data: AppointmentFormData) {
  try {
    // Validate data
    const validatedData = AppointmentSchema.parse(data)

    // Check if patient exists
    const patient = await prisma.patient.findUnique({
      where: { patientID: validatedData.patientID },
    })

    if (!patient) {
      return { error: "The selected patient does not exist" }
    }

    // Check if doctor exists
    const doctor = await prisma.doctor.findUnique({
      where: { doctorID: validatedData.doctorID },
    })

    if (!doctor) {
      return { error: "The selected doctor does not exist" }
    }

    // Update appointment
    const appointment = await prisma.appointment.update({
      where: { appointmentID: id },
      data: validatedData,
    })

    revalidatePath("/appointments")
    return { appointment }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error(`Failed to update appointment with ID ${id}:`, error)
    return { error: `Failed to update appointment with ID ${id}` }
  }
}

export async function deleteAppointment(id: number) {
  try {
    // Delete appointment
    await prisma.appointment.delete({
      where: { appointmentID: id },
    })

    revalidatePath("/appointments")
    return { success: true }
  } catch (error) {
    console.error(`Failed to delete appointment with ID ${id}:`, error)
    return { error: `Failed to delete appointment with ID ${id}` }
  }
}

export async function updateAppointmentStatus(id: number, status: "scheduled" | "completed" | "cancelled") {
  try {
    // Update appointment status
    const appointment = await prisma.appointment.update({
      where: { appointmentID: id },
      data: { status },
    })

    revalidatePath("/appointments")
    return { appointment }
  } catch (error) {
    console.error(`Failed to update status for appointment with ID ${id}:`, error)
    return { error: `Failed to update status for appointment with ID ${id}` }
  }
}

