"use server"

import { prisma } from "@/lib/db"

export async function getDashboardStats() {
  try {
    // Get counts
    const patientCount = await prisma.patient.count()
    const doctorCount = await prisma.doctor.count()
    const departmentCount = await prisma.department.count()
    const employeeCount = await prisma.employee.count()

    // Get recent appointments
    const recentAppointments = await prisma.appointment.findMany({
      take: 5,
      orderBy: { appointmentDate: "desc" },
      include: {
        patient: true,
        doctor: true,
      },
    })

    // Get appointment stats
    const appointmentStats = await prisma.appointment.groupBy({
      by: ["status"],
      _count: {
        appointmentID: true,
      },
    })

    // Get department distribution
    const departmentDistribution = await prisma.doctor.groupBy({
      by: ["departmentID"],
      _count: {
        doctorID: true,
      },
    })

    // Get department names for the distribution
    const departments = await prisma.department.findMany({
      select: {
        departmentID: true,
        name: true,
      },
    })

    // Map department IDs to names in the distribution
    const departmentData = departmentDistribution.map((item) => ({
      departmentID: item.departmentID,
      name: departments.find((d) => d.departmentID === item.departmentID)?.name || "Unknown",
      count: item._count.doctorID,
    }))

    // Get monthly patient registration for the past 6 months
    const sixMonthsAgo = new Date()
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)

    const patientRegistrations = await prisma.patient.groupBy({
      by: ["registrationDate"],
      _count: {
        patientID: true,
      },
      where: {
        registrationDate: {
          gte: sixMonthsAgo,
        },
      },
    })

    // Format the data for charts
    const monthlyData = Array.from({ length: 6 }, (_, i) => {
      const date = new Date()
      date.setMonth(date.getMonth() - i)
      const month = date.toLocaleString("default", { month: "short" })
      const year = date.getFullYear()
      const monthYear = `${month} ${year}`

      // Find registrations for this month
      const monthRegistrations = patientRegistrations.filter((reg) => {
        const regDate = new Date(reg.registrationDate)
        return regDate.getMonth() === date.getMonth() && regDate.getFullYear() === date.getFullYear()
      })

      // Sum up the counts for the month
      const count = monthRegistrations.reduce((sum, reg) => sum + reg._count.patientID, 0)

      return {
        name: month,
        count,
      }
    }).reverse()

    return {
      counts: {
        patients: patientCount,
        doctors: doctorCount,
        departments: departmentCount,
        employees: employeeCount,
      },
      recentAppointments,
      appointmentStats,
      departmentData,
      patientRegistrationData: monthlyData,
    }
  } catch (error) {
    console.error("Failed to fetch dashboard stats:", error)
    return { error: "Failed to fetch dashboard stats" }
  }
}

