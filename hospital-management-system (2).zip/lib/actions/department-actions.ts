"use server"

import { prisma } from "@/lib/db"
import { revalidatePath } from "next/cache"
import { z } from "zod"

// Validation schema
const DepartmentSchema = z.object({
  departmentID: z.coerce.number().positive(),
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  description: z.string().optional(),
  headDoctor: z.string().min(2),
  location: z.string().min(2),
  contactExt: z.string().min(2),
  establishedDate: z.string().transform((str) => new Date(str)),
})

export type DepartmentFormData = z.infer<typeof DepartmentSchema>

export async function getDepartments() {
  try {
    const departments = await prisma.department.findMany({
      include: {
        doctors: true,
        employees: true,
      },
      orderBy: { createdAt: "desc" },
    })
    return { departments }
  } catch (error) {
    console.error("Failed to fetch departments:", error)
    return { error: "Failed to fetch departments" }
  }
}

export async function getDepartmentById(id: number) {
  try {
    const department = await prisma.department.findUnique({
      where: { departmentID: id },
      include: {
        doctors: true,
        employees: true,
      },
    })
    return { department }
  } catch (error) {
    console.error(`Failed to fetch department with ID ${id}:`, error)
    return { error: `Failed to fetch department with ID ${id}` }
  }
}

export async function createDepartment(data: DepartmentFormData) {
  try {
    // Validate data
    const validatedData = DepartmentSchema.parse(data)

    // Check if department ID already exists
    const existingDepartment = await prisma.department.findUnique({
      where: { departmentID: validatedData.departmentID },
    })

    if (existingDepartment) {
      return { error: "A department with this ID already exists" }
    }

    // Create department
    const department = await prisma.department.create({
      data: validatedData,
    })

    revalidatePath("/departments")
    return { department }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error("Failed to create department:", error)
    return { error: "Failed to create department" }
  }
}

export async function updateDepartment(id: number, data: DepartmentFormData) {
  try {
    // Validate data
    const validatedData = DepartmentSchema.parse(data)

    // Update department
    const department = await prisma.department.update({
      where: { departmentID: id },
      data: validatedData,
    })

    revalidatePath("/departments")
    return { department }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error(`Failed to update department with ID ${id}:`, error)
    return { error: `Failed to update department with ID ${id}` }
  }
}

export async function deleteDepartment(id: number) {
  try {
    // Check if department has doctors or employees
    const departmentWithRelations = await prisma.department.findUnique({
      where: { departmentID: id },
      include: {
        doctors: true,
        employees: true,
      },
    })

    if (departmentWithRelations?.doctors.length) {
      return { error: "Cannot delete department with assigned doctors" }
    }

    if (departmentWithRelations?.employees.length) {
      return { error: "Cannot delete department with assigned employees" }
    }

    // Delete department
    await prisma.department.delete({
      where: { departmentID: id },
    })

    revalidatePath("/departments")
    return { success: true }
  } catch (error) {
    console.error(`Failed to delete department with ID ${id}:`, error)
    return { error: `Failed to delete department with ID ${id}` }
  }
}

