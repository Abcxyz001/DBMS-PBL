"use server"

import { prisma } from "@/lib/db"
import { revalidatePath } from "next/cache"
import { z } from "zod"

// Validation schema
const DoctorSchema = z.object({
  doctorID: z.coerce.number().positive(),
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  specialty: z.string().min(2),
  departmentID: z.coerce.number().positive(),
  qualification: z.string().min(2),
  experience: z.coerce.number().nonnegative(),
  contact: z.string().min(5),
  email: z.string().email(),
  schedule: z.string(),
  joinDate: z.string().transform((str) => new Date(str)),
})

export type DoctorFormData = z.infer<typeof DoctorSchema>

export async function getDoctors() {
  try {
    const doctors = await prisma.doctor.findMany({
      include: { department: true },
      orderBy: { createdAt: "desc" },
    })
    return { doctors }
  } catch (error) {
    console.error("Failed to fetch doctors:", error)
    return { error: "Failed to fetch doctors" }
  }
}

export async function getDoctorById(id: number) {
  try {
    const doctor = await prisma.doctor.findUnique({
      where: { doctorID: id },
      include: { department: true },
    })
    return { doctor }
  } catch (error) {
    console.error(`Failed to fetch doctor with ID ${id}:`, error)
    return { error: `Failed to fetch doctor with ID ${id}` }
  }
}

export async function createDoctor(data: DoctorFormData) {
  try {
    // Validate data
    const validatedData = DoctorSchema.parse(data)

    // Check if doctor ID already exists
    const existingDoctor = await prisma.doctor.findUnique({
      where: { doctorID: validatedData.doctorID },
    })

    if (existingDoctor) {
      return { error: "A doctor with this ID already exists" }
    }

    // Check if department exists
    const department = await prisma.department.findUnique({
      where: { departmentID: validatedData.departmentID },
    })

    if (!department) {
      return { error: "The selected department does not exist" }
    }

    // Create doctor
    const doctor = await prisma.doctor.create({
      data: validatedData,
    })

    revalidatePath("/doctors")
    return { doctor }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error("Failed to create doctor:", error)
    return { error: "Failed to create doctor" }
  }
}

export async function updateDoctor(id: number, data: DoctorFormData) {
  try {
    // Validate data
    const validatedData = DoctorSchema.parse(data)

    // Check if department exists
    const department = await prisma.department.findUnique({
      where: { departmentID: validatedData.departmentID },
    })

    if (!department) {
      return { error: "The selected department does not exist" }
    }

    // Update doctor
    const doctor = await prisma.doctor.update({
      where: { doctorID: id },
      data: validatedData,
    })

    revalidatePath("/doctors")
    return { doctor }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error(`Failed to update doctor with ID ${id}:`, error)
    return { error: `Failed to update doctor with ID ${id}` }
  }
}

export async function deleteDoctor(id: number) {
  try {
    // Check if doctor has appointments
    const doctorWithAppointments = await prisma.doctor.findUnique({
      where: { doctorID: id },
      include: { appointments: true },
    })

    if (doctorWithAppointments?.appointments.length) {
      return { error: "Cannot delete doctor with existing appointments" }
    }

    // Delete doctor
    await prisma.doctor.delete({
      where: { doctorID: id },
    })

    revalidatePath("/doctors")
    return { success: true }
  } catch (error) {
    console.error(`Failed to delete doctor with ID ${id}:`, error)
    return { error: `Failed to delete doctor with ID ${id}` }
  }
}

