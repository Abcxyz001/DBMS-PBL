"use server"

import { prisma } from "@/lib/db"
import { revalidatePath } from "next/cache"
import { z } from "zod"

// Validation schema
const EmployeeSchema = z.object({
  employeeID: z.coerce.number().positive(),
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  role: z.string().min(2),
  departmentID: z.coerce.number().positive(),
  contact: z.string().min(5),
  email: z.string().email(),
  address: z.string().optional(),
  joinDate: z.string().transform((str) => new Date(str)),
  salary: z.coerce.number().positive(),
  status: z.enum(["active", "on leave", "terminated"]),
})

export type EmployeeFormData = z.infer<typeof EmployeeSchema>

export async function getEmployees() {
  try {
    const employees = await prisma.employee.findMany({
      include: { department: true },
      orderBy: { createdAt: "desc" },
    })
    return { employees }
  } catch (error) {
    console.error("Failed to fetch employees:", error)
    return { error: "Failed to fetch employees" }
  }
}

export async function getEmployeeById(id: number) {
  try {
    const employee = await prisma.employee.findUnique({
      where: { employeeID: id },
      include: { department: true },
    })
    return { employee }
  } catch (error) {
    console.error(`Failed to fetch employee with ID ${id}:`, error)
    return { error: `Failed to fetch employee with ID ${id}` }
  }
}

export async function createEmployee(data: EmployeeFormData) {
  try {
    // Validate data
    const validatedData = EmployeeSchema.parse(data)

    // Check if employee ID already exists
    const existingEmployee = await prisma.employee.findUnique({
      where: { employeeID: validatedData.employeeID },
    })

    if (existingEmployee) {
      return { error: "An employee with this ID already exists" }
    }

    // Check if department exists
    const department = await prisma.department.findUnique({
      where: { departmentID: validatedData.departmentID },
    })

    if (!department) {
      return { error: "The selected department does not exist" }
    }

    // Create employee
    const employee = await prisma.employee.create({
      data: validatedData,
    })

    revalidatePath("/employees")
    return { employee }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error("Failed to create employee:", error)
    return { error: "Failed to create employee" }
  }
}

export async function updateEmployee(id: number, data: EmployeeFormData) {
  try {
    // Validate data
    const validatedData = EmployeeSchema.parse(data)

    // Check if department exists
    const department = await prisma.department.findUnique({
      where: { departmentID: validatedData.departmentID },
    })

    if (!department) {
      return { error: "The selected department does not exist" }
    }

    // Update employee
    const employee = await prisma.employee.update({
      where: { employeeID: id },
      data: validatedData,
    })

    revalidatePath("/employees")
    return { employee }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error(`Failed to update employee with ID ${id}:`, error)
    return { error: `Failed to update employee with ID ${id}` }
  }
}

export async function deleteEmployee(id: number) {
  try {
    // Delete employee
    await prisma.employee.delete({
      where: { employeeID: id },
    })

    revalidatePath("/employees")
    return { success: true }
  } catch (error) {
    console.error(`Failed to delete employee with ID ${id}:`, error)
    return { error: `Failed to delete employee with ID ${id}` }
  }
}

