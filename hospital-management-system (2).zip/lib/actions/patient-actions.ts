"use server"

import { prisma } from "@/lib/db"
import { revalidatePath } from "next/cache"
import { z } from "zod"

// Validation schema
const PatientSchema = z.object({
  patientID: z.coerce.number().positive(),
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  age: z.coerce.number().positive(),
  gender: z.string().min(1),
  contact: z.string().min(5),
  email: z.string().email().optional().or(z.literal("")),
  address: z.string().optional(),
  medicalHistory: z.string().optional(),
  bloodGroup: z.string(),
  registrationDate: z.string().transform((str) => new Date(str)),
})

export type PatientFormData = z.infer<typeof PatientSchema>

export async function getPatients() {
  try {
    const patients = await prisma.patient.findMany({
      orderBy: { createdAt: "desc" },
    })
    return { patients }
  } catch (error) {
    console.error("Failed to fetch patients:", error)
    return { error: "Failed to fetch patients" }
  }
}

export async function getPatientById(id: number) {
  try {
    const patient = await prisma.patient.findUnique({
      where: { patientID: id },
    })
    return { patient }
  } catch (error) {
    console.error(`Failed to fetch patient with ID ${id}:`, error)
    return { error: `Failed to fetch patient with ID ${id}` }
  }
}

export async function createPatient(data: PatientFormData) {
  try {
    // Validate data
    const validatedData = PatientSchema.parse(data)

    // Check if patient ID already exists
    const existingPatient = await prisma.patient.findUnique({
      where: { patientID: validatedData.patientID },
    })

    if (existingPatient) {
      return { error: "A patient with this ID already exists" }
    }

    // Create patient
    const patient = await prisma.patient.create({
      data: validatedData,
    })

    revalidatePath("/patients")
    return { patient }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error("Failed to create patient:", error)
    return { error: "Failed to create patient" }
  }
}

export async function updatePatient(id: number, data: PatientFormData) {
  try {
    // Validate data
    const validatedData = PatientSchema.parse(data)

    // Update patient
    const patient = await prisma.patient.update({
      where: { patientID: id },
      data: validatedData,
    })

    revalidatePath("/patients")
    return { patient }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { error: error.errors.map((e) => e.message).join(", ") }
    }
    console.error(`Failed to update patient with ID ${id}:`, error)
    return { error: `Failed to update patient with ID ${id}` }
  }
}

export async function deletePatient(id: number) {
  try {
    // Check if patient has appointments
    const patientWithAppointments = await prisma.patient.findUnique({
      where: { patientID: id },
      include: { appointments: true },
    })

    if (patientWithAppointments?.appointments.length) {
      return { error: "Cannot delete patient with existing appointments" }
    }

    // Delete patient
    await prisma.patient.delete({
      where: { patientID: id },
    })

    revalidatePath("/patients")
    return { success: true }
  } catch (error) {
    console.error(`Failed to delete patient with ID ${id}:`, error)
    return { error: `Failed to delete patient with ID ${id}` }
  }
}

