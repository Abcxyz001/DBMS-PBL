export interface Patient {
  patientID: number
  name: string
  age: number
  gender: string
  contact: string
  email: string
  address: string
  medicalHistory: string
  bloodGroup: string
  registrationDate: string
}

export interface Doctor {
  doctorID: number
  name: string
  specialty: string
  departmentID: number
  qualification: string
  experience: number
  contact: string
  email: string
  schedule: string
  joinDate: string
}

export interface Appointment {
  appointmentID: number
  patient: Patient
  doctor: Doctor
  appointmentDate: string
  appointmentTime: string
  status: "scheduled" | "completed" | "cancelled"
  purpose: string
  notes: string
}

export interface Department {
  departmentID: number
  name: string
  description: string
  headDoctor: string
  location: string
  contactExt: string
  establishedDate: string
}

export interface Employee {
  employeeID: number
  name: string
  role: string
  departmentID: number
  contact: string
  email: string
  address: string
  joinDate: string
  salary: number
  status: "active" | "on leave" | "terminated"
}

export type AppointmentStatus = "scheduled" | "completed" | "cancelled"
export type EmployeeStatus = "active" | "on leave" | "terminated"

